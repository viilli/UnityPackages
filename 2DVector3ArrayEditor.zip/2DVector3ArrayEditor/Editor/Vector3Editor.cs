using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.Reflection;

public class Vector3Editor : EditorWindow
{

    //Script prpperties
    private static MonoBehaviour scriptInstance;
    private static SerializedObject serializedObject;

    //Array
    private static string selectedArrayName;
    private static SerializedProperty selectedArrayProperty;
    private static List<string> arrayNames = new List<string>();

    //Edit
    private static bool allowEditBySettings;
    private static bool allowEditByUser;
    private static bool allowEdit;

    private static int selectedPointIndex = -1;
    private static Vector3 originalPosition;
    private static bool pressed;


    [MenuItem("Window/2dEditor/Vector3ArrayEditor")]
    public static void ShowWindow()
    {
        GetWindow(typeof(Vector3Editor));
        //SceneView.onCameraModeChanged += OnSceneGUI;
        SceneView.duringSceneGui += OnSceneGUI;
    }

    private void OnGUI()
    {
 
        EditorGUILayout.LabelField("Vector3 array editor", EditorStyles.boldLabel);
        EditorGUILayout.LabelField("To add and move the points you \n can use buttons \"O\" or \"F15\" (can be set as macro in mouse", EditorStyles.wordWrappedLabel);

        scriptInstance = EditorGUILayout.ObjectField("Script Instance", scriptInstance, typeof(MonoBehaviour), true) as MonoBehaviour;

        if (scriptInstance != null)
        {
            if (serializedObject == null || serializedObject.targetObject != scriptInstance)
            {
                serializedObject = new SerializedObject(scriptInstance);
                FindArrayProperties();
            }

            serializedObject.Update();

            if (arrayNames.Count > 0)
            {
                int selectedIndex = EditorGUILayout.Popup("Array", arrayNames.IndexOf(selectedArrayName), arrayNames.ToArray());
                if (selectedIndex != -1)
                {
                    selectedArrayName = arrayNames[selectedIndex];
                    selectedArrayProperty = serializedObject.FindProperty(selectedArrayName);

                    if (selectedArrayProperty != null)
                    {

                    }
                }
            }

            if (selectedArrayProperty != null)
            {
                allowEditByUser = EditorGUILayout.Toggle("Allow editing", allowEditByUser);
                allowEditBySettings = true;
            }
            else allowEditBySettings = false;

        }
        else allowEditBySettings = false;


        if (allowEditBySettings && allowEditByUser)
        {
            allowEdit = true;
        }
        else
        {
            allowEdit = false;
        }

        if (allowEdit)
        {
            SceneView.RepaintAll();
        }

        DisplayArray();

        if (serializedObject != null)
        {
            serializedObject.ApplyModifiedProperties();
        }
        

    }

    public static void OnSceneGUI(SceneView s)
    {

        Event currentEvent = Event.current;

        if (currentEvent.type == EventType.KeyDown)
        {

        }
        if (allowEdit)
        {
            if ((currentEvent.keyCode == KeyCode.O || currentEvent.keyCode == KeyCode.F15) && currentEvent.type == EventType.KeyDown && !pressed)
            {
                pressed = true;
                selectedPointIndex = -1;
                Vector2 mousePosition = currentEvent.mousePosition;
                Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);
                Vector3 worldPosition = ray.origin;
                Vector3 flatWorldPosition = new Vector3(worldPosition.x, worldPosition.y, 0);

                for (int pointIdx = 0; pointIdx < selectedArrayProperty.arraySize; pointIdx++)
                {
                    float t = Vector3.Distance(selectedArrayProperty.GetArrayElementAtIndex(pointIdx).vector3Value, flatWorldPosition);
                    if (t < 0.3f)
                    {
                        selectedPointIndex = pointIdx;
                        originalPosition = flatWorldPosition;
                        break;
                    }
                }


                if (selectedPointIndex == -1)
                {
                    // Delete point if no movement
                    selectedArrayProperty.arraySize++;
                    var newElement = selectedArrayProperty.GetArrayElementAtIndex(selectedArrayProperty.arraySize - 1);
                    newElement.vector3Value = flatWorldPosition;
                    serializedObject.ApplyModifiedProperties();
                }
            }

            else if ((currentEvent.keyCode == KeyCode.O || currentEvent.keyCode == KeyCode.F15) && currentEvent.type == EventType.KeyDown && pressed)
            {
                if (selectedPointIndex != -1)
                {
                    Vector2 mousePosition = currentEvent.mousePosition;
                    Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);
                    Vector3 worldPosition = ray.origin + ray.direction;
                    Vector3 flatWorldPosition = new Vector3(worldPosition.x, worldPosition.y, 0);

                    if (Vector3.Distance(originalPosition, flatWorldPosition) > 0.0001f)
                    {
                        var selectedElement = selectedArrayProperty.GetArrayElementAtIndex(selectedPointIndex);
                        selectedElement.vector3Value = flatWorldPosition;
                        serializedObject.ApplyModifiedProperties();
                    }

                }
            }

            if ((currentEvent.keyCode == KeyCode.O || currentEvent.keyCode == KeyCode.F15) && currentEvent.type == EventType.KeyUp && pressed)
            {
                pressed = false;
                if (selectedPointIndex != -1)
                {
                    Vector2 mousePosition = currentEvent.mousePosition;
                    Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);
                    Vector3 worldPosition = ray.origin + ray.direction;
                    Vector3 flatWorldPosition = new Vector3(worldPosition.x, worldPosition.y, 0);
                    if (Vector3.Distance(originalPosition, flatWorldPosition) < 0.1f)
                    {
                        selectedArrayProperty.DeleteArrayElementAtIndex(selectedPointIndex);
                        serializedObject.ApplyModifiedProperties();
                        //RepaintTheScene();
                    }
                }

                selectedPointIndex = -1;
            }

            if ((currentEvent.keyCode == KeyCode.O || currentEvent.keyCode == KeyCode.F15) && currentEvent.type == EventType.KeyUp && pressed)
            {
                pressed = false;
                if (selectedPointIndex != -1)
                {

                    Vector2 mousePosition = currentEvent.mousePosition;
                    Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);
                    Vector3 worldPosition = ray.origin + ray.direction;
                    Vector3 flatWorldPosition = new Vector3(worldPosition.x, worldPosition.y, 0);

                    if (Vector3.Distance(originalPosition, flatWorldPosition) < 0.1f)
                    {
                        var selectedElement = selectedArrayProperty.GetArrayElementAtIndex(selectedPointIndex);
                        selectedElement.vector3Value = flatWorldPosition;
                        serializedObject.ApplyModifiedProperties();
                        //RepaintTheScene();
                    }
                }

                selectedPointIndex = -1;
            }

            HandleUtility.AddDefaultControl(GUIUtility.GetControlID(FocusType.Passive));
            RepaintTheScene();
            RepaintAll();
        }
    }

    private static void DisplayArray()
    {
        GUILayout.Label("Array");
        if (GUILayout.Button("Clear Array"))
        {
            selectedArrayProperty.ClearArray();
            Handles.DrawSolidDisc(Vector3.zero, Vector3.forward, 1f);

        }


        if (selectedArrayProperty != null)
        {
            for (int i = 0; i < selectedArrayProperty.arraySize; i++)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.PropertyField(selectedArrayProperty.GetArrayElementAtIndex(i), GUIContent.none);
                if (GUILayout.Button("Remove", GUILayout.Width(60)))
                {
                    selectedArrayProperty.DeleteArrayElementAtIndex(i);
                    break;
                }
                EditorGUILayout.EndHorizontal();
            }
        }
    }

    public static void RepaintTheScene()
    {
        for (int j = 0; j < selectedArrayProperty.arraySize; j++)
        {
            var currentElement = selectedArrayProperty.GetArrayElementAtIndex(j);

            Vector3 currentPos = new Vector3(currentElement.vector3Value.x, currentElement.vector3Value.y, 0);

            var nextElement = selectedArrayProperty.GetArrayElementAtIndex((j + 1) % selectedArrayProperty.arraySize);
            Vector3 nextPos = new Vector3(nextElement.vector3Value.x, nextElement.vector3Value.y, 0);
            Handles.DrawSolidDisc(currentPos, Vector3.forward, 0.2f);
            Handles.DrawLine(currentPos, nextPos);

            // Print the index next to the current point
            Handles.Label(currentPos + new Vector3(0.5f, 0, 0), j.ToString());
        }

    }

    private static void FindArrayProperties()
    {
        arrayNames.Clear();
        selectedArrayName = string.Empty;
        selectedArrayProperty = null;

        FieldInfo[] fields = scriptInstance.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

        foreach (FieldInfo field in fields)
        {
            if (field.FieldType.IsArray)
            {
                arrayNames.Add(field.Name);
            }
        }
    }

    private static void RepaintAll()
    {
        // Iterate through all open EditorWindows
        // Find all open EditorWindows
        var windows = Resources.FindObjectsOfTypeAll<EditorWindow>();
        foreach (var window in windows)
        {
            // Check if the window is an instance of your custom editor window
            if (window.GetType() == typeof(Vector3Editor))
            {
                window.Repaint();
            }
        }
    }
}

